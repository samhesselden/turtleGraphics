public class Main 
{
	public static void main(String[] arg)
	{
		new GraphicsSystem();
		new GUI();	
	}
}
